package queue;
import java.util.*;
public class SlidingWindowMaximum {
    public static int[] solve(int[] a,int k){
        Deque<Integer> dq=new ArrayDeque<>();
        int[] res=new int[a.length-k+1];
        for(int i=0;i<a.length;i++){
            if(!dq.isEmpty()&&dq.peek()<i-k+1) dq.poll();
            while(!dq.isEmpty()&&a[dq.peekLast()]<a[i]) dq.pollLast();
            dq.offer(i);
            if(i>=k-1) res[i-k+1]=a[dq.peek()];
        }
        return res;
    }
}