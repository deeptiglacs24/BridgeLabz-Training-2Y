
class IslandCount {
    static int[] dx = {0, 0, 1, -1};
    static int[] dy = {1, -1, 0, 0};

    public static int numIslands(int[][] grid) {
        int count = 0;
        for(int i=0;i<grid.length;i++){
            for(int j=0;j<grid[0].length;j++){
                if(grid[i][j] == 1){
                    dfs(grid,i,j);
                    count++;
                }
            }
        }
        return count;
    }

    static void dfs(int[][] grid,int i,int j){
        if(i<0||j<0||i>=grid.length||j>=grid[0].length||grid[i][j]==0) return;
        grid[i][j]=0;
        for(int d=0;d<4;d++){
            dfs(grid,i+dx[d],j+dy[d]);
        }
    }
}
