
import java.util.*;

class TopologicalSort {
    public static void topoSort(List<List<Integer>> graph, int V){
        int[] indegree = new int[V];

        for(int i=0;i<V;i++){
            for(int neigh: graph.get(i)){
                indegree[neigh]++;
            }
        }

        Queue<Integer> q = new LinkedList<>();
        for(int i=0;i<V;i++){
            if(indegree[i]==0) q.add(i);
        }

        while(!q.isEmpty()){
            int node = q.poll();
            System.out.print(node+" ");

            for(int neigh: graph.get(node)){
                indegree[neigh]--;
                if(indegree[neigh]==0) q.add(neigh);
            }
        }
    }
}
