
import java.util.*;

class DFS {
    public static void dfs(List<List<Integer>> graph, int node, boolean[] visited) {
        visited[node] = true;
        System.out.print(node + " ");

        for(int neighbor : graph.get(node)) {
            if(!visited[neighbor]) {
                dfs(graph, neighbor, visited);
            }
        }
    }
}
